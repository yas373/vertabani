import UIKit

var str = "Hello, playground"
print(str)

var sayi = "merhaba"

var belirliDegisken : String = "asda"

var optinal : String?

optinal = "Neslihan"

print(optinal!)

if let optinalValue = optinal {
    print(optinalValue)
}


func getString(stringValue: String? = nil) -> String?{
    guard let optinalValueWithGuard = stringValue else {
        print("Değer nil geldi")
        return nil
    }
    
    return optinalValueWithGuard
}

getString(stringValue: optinal)

var dizi = [0,1,2,3]

struct Person{
    
    var name: String?
    var surname: String?
    
}

Person(name: "Neslihan", surname: "Turpcu")

var kisi = Person()
kisi.name = "deneme"

class Kisi{
    var name: String?
    
    init(nameValue: String) {
        self.name = nameValue
    }
    
    init() {
    }
}

Kisi(nameValue: "Denem")
Kisi()

for i in 0...dizi.count - 1 {
}

do {
    _ = try dizi.count
} catch {
    print("Hata aldı")
}
